#Nicholas Alexander Wang          9-8-2022
# Lab Week 3 - Exercise #4
import math


base = float(input("Enter base Value :"))
height = float(input("enter height value :"))

area = (base*height)/2

print("size of base: ", base)
print("height of triangle :", height)
print("the area is ",area)