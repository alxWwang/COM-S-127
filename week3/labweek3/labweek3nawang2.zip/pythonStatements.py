import math

print(
    min(1,2,3,4,5) == 7%2,
    float(round(10.4,0)),
    pow(2,-2) == pow(2,.25),
    pow(float(round(3.4,0)),float(round(3.4,0))),
    pow(max(1,2,3),min(4,5,6)),
)