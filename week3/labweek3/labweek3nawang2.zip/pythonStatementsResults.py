## statement : min(1,2,3,4,5) == 7%2
print("min(1,2,3,4,5) == 7%2")
print("hand Computed answer : True")
print("computer generated answer : True")


## statement :float(round(10.4,0))
print("float(round(10.4,0)")
print("hand Computed answer : 10")
print("computer generated answer : 10")

## statement :pow(2,-2) == pow(2,.25)
print("pow(2,-2) == pow(2,.25)")
print("hand Computed answer : False")
print("computer generated answer : False")

## statement :pow(float(round(3.4,0)),float(round(3.4,0)))
print("pow(float(round(3.4,0)),float(round(3.4,0)))")
print("hand Computed answer : 27")
print("computer generated answer : 27")

## statement :pow(max(1,2,3),min(4,5,6))
print("pow(max(1,2,3),min(4,5,6))")
print("hand Computed answer : 81")
print("computer generated answer : 81")

##Exercise 4
'''
size of base:  20.0
height of triangle : 4.0
the area is  40.0

'''

##Excercise 5
'''
input class 1 : ab
Grade : 12
input class 2 : cd
Grade : 23
input class 3 : de
Grade : 34
input class 4 : ef
Grade : 45
the average of ab, cd, de, ef is 28.5


'''
